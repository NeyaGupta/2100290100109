import React, { useEffect, useState } from 'react';
import Filter from '../components/Filter';
import Pagination from '../components/Pagination';
import ProductCard from '../components/ProductCard';
import Sort from '../components/Sort';
import { fetchProducts } from '../services/api';

const ProductsPage = () => {
  const [products, setProducts] = useState([]);
  const [filters, setFilters] = useState({});
  const [sort, setSort] = useState({});
  const [page, setPage] = useState(1);

  useEffect(() => {
    const getProducts = async () => {
      const response = await fetchProducts('AMZ', 'Laptop', 10, 1, 10000);
      setProducts(response.data);
    };
    getProducts();
  }, [filters, sort, page]);

  return (
    <div>
      <Filter setFilters={setFilters} />
      <Sort setSort={setSort} />
      <div>
        {products.map(product => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
      <Pagination page={page} setPage={setPage} />
    </div>
  );
};

export default ProductsPage;
