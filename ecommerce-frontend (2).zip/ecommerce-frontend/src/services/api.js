import axios from 'axios';

const API_URL = 'http://20.244.56.144/test/companies';

const fetchProducts = (companyName, categoryName, topN, minPrice, maxPrice) => {
  return axios.get(`${API_URL}/${companyName}/categories/${categoryName}/products/top-${topN}`, {
    params: { minPrice, maxPrice }
  });
};

export { fetchProducts };
