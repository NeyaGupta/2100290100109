import React from 'react';

const Pagination = ({ page, setPage }) => {
  const handlePrevPage = () => setPage(prevPage => Math.max(prevPage - 1, 1));
  const handleNextPage = () => setPage(prevPage => prevPage + 1);

  return (
    <div>
      <button onClick={handlePrevPage}>Previous</button>
      <span>Page {page}</span>
      <button onClick={handleNextPage}>Next</button>
    </div>
  );
};

export default Pagination;
