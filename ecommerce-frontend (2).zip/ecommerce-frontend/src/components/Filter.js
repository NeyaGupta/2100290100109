import React from 'react';

const Filter = ({ setFilters }) => {
  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters(prevFilters => ({ ...prevFilters, [name]: value }));
  };

  return (
    <div>
      <input type="text" name="category" placeholder="Category" onChange={handleFilterChange} />
      <input type="text" name="company" placeholder="Company" onChange={handleFilterChange} />
      <input type="number" name="rating" placeholder="Rating" onChange={handleFilterChange} />
      <input type="number" name="minPrice" placeholder="Min Price" onChange={handleFilterChange} />
      <input type="number" name="maxPrice" placeholder="Max Price" onChange={handleFilterChange} />
      <select name="availability" onChange={handleFilterChange}>
        <option value="">All</option>
        <option value="yes">In Stock</option>
        <option value="out-of-stock">Out of Stock</option>
      </select>
    </div>
  );
};

export default Filter;
