import React from 'react';

const Sort = ({ setSort }) => {
  const handleSortChange = (e) => {
    const { name, value } = e.target;
    setSort(prevSort => ({ ...prevSort, [name]: value }));
  };

  return (
    <div>
      <select name="sortBy" onChange={handleSortChange}>
        <option value="price">Price</option>
        <option value="rating">Rating</option>
        <option value="discount">Discount</option>
      </select>
    </div>
  );
};

export default Sort;
