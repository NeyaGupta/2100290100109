const express = require('express');
const axios = require('axios');
const cors = require('cors');

const app = express();
const port = 9876;
const windowSize = 10;
let numberWindow = [];

app.use(cors());

const fetchNumbers = async (type) => {
  const urlMap = {
    p: 'http://20.244.56.144/test/primes',
    f: 'http://20.244.56.144/test/fibo',
    e: 'http://20.244.56.144/test/even',
    r: 'http://20.244.56.144/test/rand',
  };

  try {
    console.log(`Fetching numbers of type: ${type}`);
    const response = await axios.get(urlMap[type], { timeout: 500 });
    console.log(`Fetched numbers: ${response.data.numbers}`);
    return response.data.numbers;
  } catch (error) {
    console.error('Error fetching numbers:', error.message);
    return [];
  }
};

const calculateAverage = (numbers) => {
  if (numbers.length === 0) return 0;
  const sum = numbers.reduce((acc, num) => acc + num, 0);
  return (sum / numbers.length).toFixed(2);
};

app.get('/numbers/:type', async (req, res) => {
  const type = req.params.type;

  if (!['p', 'f', 'e', 'r'].includes(type)) {
    return res.status(400).json({ error: 'Invalid type' });
  }

  const numbers = await fetchNumbers(type);
  const uniqueNumbers = numbers.filter(num => !numberWindow.includes(num));

  const windowPrevState = [...numberWindow];

  uniqueNumbers.forEach(num => {
    if (numberWindow.length < windowSize) {
      numberWindow.push(num);
    } else {
      numberWindow.shift();
      numberWindow.push(num);
    }
  });

  const windowCurrState = [...numberWindow];
  const average = calculateAverage(numberWindow);

  res.json({
    windowPrevState,
    windowCurrState,
    numbers: uniqueNumbers,
    avg: average,
  });
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
