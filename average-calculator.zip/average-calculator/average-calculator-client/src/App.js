import React from 'react';
import './App.css';
import AverageCalculator from './AverageCalculator';

function App() {
  return (
    <div className="App">
      <AverageCalculator />
    </div>
  );
}

export default App;
